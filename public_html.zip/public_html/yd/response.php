<?php
define('BASE_PATH', __DIR__ . "/../");
define('WP_USE_THEMES', false);
global $wp, $wp_query, $wp_the_query, $wp_rewrite, $wp_did_header, $wpdb;
require_once(BASE_PATH . 'wp-load.php');
?>
<?php
$key = ''; // секретное слово, которое мы получили в предыдущем шаге.
 
// возможно некоторые из нижеперечисленных параметров вам пригодятся
// $_POST['operation_id'] - номер операция
// $_POST['amount'] - количество денег, которые поступят на счет получателя
// $_POST['withdraw_amount'] - количество денег, которые будут списаны со счета покупателя
// $_POST['datetime'] - тут понятно, дата и время оплаты
// $_POST['sender'] - если оплата производится через Яндекс Деньги, то этот параметр содержит номер кошелька покупателя
// $_POST['label'] - лейбл, который мы указывали в форме оплаты
// $_POST['email'] - email покупателя (доступен только при использовании https://)
 

$id        =trim($_POST['label']);    
$order     =trim($_POST['operation_id']);       
$payer     =trim($_POST['sender']);      
$odate     =trim($_POST['datetime']);   
$code      =trim($_POST['codepro']);       
$amount    =trim($_POST['amount']);    
$wamount   =trim($_POST['withdraw_amount']);   
$cur       =trim($_POST['currency']);   
$type      =trim($_POST['notification_type']);  
$hash      =trim($_POST['sha1_hash']);   


$hash_gen = hash("sha1", $type.'&'.$order.'&'.$amount.'&'.$cur.'&'.$odate.'&'.$payer.'&'.$code.'&'.$key.'&'.$id);
if($hash_gen!=$hash){
  exit('Error');
} // ошибка
else{


  $row = $wpdb->get_row( "SELECT * FROM order_list WHERE id = {$_POST['label']} LIMIT 0,1" );

    //Шлем письмо на e-mail
  $to = $isTestOrder ? 'cadaver@tut.by' : "cadaver@tut.by";

  $mes1 = "
    Номер заказа ".$row->coach_id."<br>
    Коучинг: ".$row->coach_name."<br>
    Цена: ".$row->coach_price."<br>
    Информация о покупателе: ".$row->order_data."
  ";

  $from = 'advencha.life';
  $sub = '=?utf-8?B?'.base64_encode('Новая заявка').'?=';
  $headers = "From: $from\r\n" .
             "MIME-Version: 1.0\r\n" .
             "Content-type: text/html; charset=utf-8";
  mail($to, $sub, $mes1, $headers);


  //Обновляем статус заказа в БД и добавляем информацию о покупателе


   $wpdb->update( 'order_list',
    array( 'coach_status' => 1),
    array( 'coach_id' => $_POST['label'])
  );


exit('OK');

}



?>