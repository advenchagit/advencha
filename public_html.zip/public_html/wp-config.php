<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'cv10887_advecha');

/** Имя пользователя MySQL */
define('DB_USER', 'cv10887_advecha');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'haJb7CS8');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'V/C1-qPj<<56<T;;v ]E-WN%_,FsTxF|.! 0&KQV_7p62cMJa>~]PE7{w7zV6xK3');
define('SECURE_AUTH_KEY',  '4O~-J>o-.-|7E|o#};*9N((>oKKUl41%bGC.Zt.)QcVdjN5+HC-B-d7m,gi?+s0<');
define('LOGGED_IN_KEY',    'N1W3LMpB->Ga|^/K!rf^@PJL6W%E+_g<VD-5Y++/AF2(u|$^.`q17{s-O^^]3&%@');
define('NONCE_KEY',        ']-JVX(C2jS-!*238 TAL-_HDodZOGC,T`PL-:&0ROz2@=wk|CD:+.W!JZ7}8oyo-');
define('AUTH_SALT',        'AblGi$+l~=V<lox(yqS?Zn5y]4Ar1(9$)C[OFH4=]q95,#qwHG-)!I 0{tlO>6E$');
define('SECURE_AUTH_SALT', 'H1d_[Z){5P9#*A-u]L-y=N|M(p4b+t<IQ&~<X)`|>=)7T4?=s3$S|-d u [$-[S.');
define('LOGGED_IN_SALT',   '&WHBLi~M|_S&j+T/n>.3#ZD6dJw.bbcz2@^j]-n}!EU$|~-|1sV@$-P_W2Lxf}3k');
define('NONCE_SALT',       'a*nWV0kXOi~4Mr6:[lB[I[L/@kuqKklG8bcV+]c`V=w@7zrEo{3&t$dmx|fQh,M%');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'av_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 * 
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
